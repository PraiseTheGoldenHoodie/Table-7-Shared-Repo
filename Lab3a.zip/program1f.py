# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do"
# "I have not given or received any unauthorized aid on this assignment"
#
# Name: Alexander Bockelman
#       Jackson Sanders
#       Patrick Chai
#       Jose Carrillo
#       Wayne Ussery
# Section: 211
# Assignment: Lab 3a-Program 1f
# Date: 12 September 2018

Temp_f = float(input("Enter Temperature in Fahrenheit: "))
Temp_c = (Temp_f - 32)*(5/9)
print("Temperature in Celsius: ", Temp_c, "°C")