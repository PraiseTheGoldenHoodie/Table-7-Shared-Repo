# By submitting this assignment, I agree to the following:
# "Aggies do not lie, cheat, or steal, or tolerate those who do"
# "I have not given or received any unauthorized aid on this assignment"
#
# Name: Alexander Bockelman
#       Jackson Sanders
#       Patrick Chai
#       Jose Carrillo
#       Wayne Ussery
# Section: 211
# Assignment: Lab 3a-Program 1e
# Date: 12 September 2018

v_1 = float(input("Enter Velocity in Miles per Hour: "))
v_2 = v_1*(44.704/100)
print("Velocity in Meters per Second: ", v_2, "m/s")
