# By submitting this assignment, I agree to the following:
#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
#
# Name: 		Patrick Chai
# Section:		211
# Assignment:	Lab 3
# Date:	    9/12/2018
from math import*
import numpy
pounds = input("how many pounds would you like to convert to newtons? ")
pounds = int(pounds)
newtons = pounds*4.44822
newtons = str(newtons)
pounds = str(pounds)
print(pounds+" pound(s) will convert to "+newtons+" newtons")

