# By submitting this assignment, I agree to the following:
#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
#
# Name: 		Jackson Sanders
# Section:		211
# Assignment:	Lab 3a Activity 1
# Date:		    9 12 2018

# 1 pascal is equivalent to .0075 mm of mercury
pascals = input("How many Pascals would you like to convert to mm Hg?")
pascals = float(pascals)
mm_Hg = pascals*0.0075
mm_Hg = str(mm_Hg)
pascals = str(pascals)
print(""+pascals+" pascal(s) convert to "+mm_Hg+" mm_Hg")
